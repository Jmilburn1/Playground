//! Mod icon loading.
//!
//! Reads the icon file named by modDesc.xml (or the default `icon.dds`)
//! from a folder mod or from inside a zip mod. DDS textures are decoded
//! to RGBA pixels — nothing displays DDS raw, so conversion is the only
//! way the cards can show real icons. png/jpg icons are passed through as
//! encoded bytes for the UI toolkit to decode.

use std::io::{Cursor, Read};
use std::path::Path;

/// A loaded icon, ready to hand to the UI.
pub enum LoadedIcon {
    /// Decoded RGBA8 pixels (from a DDS file).
    Rgba {
        width: u32,
        height: u32,
        pixels: Vec<u8>,
    },
    /// Encoded image bytes (png/jpg).
    Encoded(Vec<u8>),
}

pub fn load_icon(mod_path: &Path, icon_filename: Option<&str>) -> Option<LoadedIcon> {
    let name = icon_filename.unwrap_or("icon.dds");
    let bytes = read_icon_bytes(mod_path, name)?;
    if bytes.starts_with(b"DDS ") || name.to_lowercase().ends_with(".dds") {
        decode_dds(&bytes)
    } else {
        Some(LoadedIcon::Encoded(bytes))
    }
}

fn read_icon_bytes(mod_path: &Path, name: &str) -> Option<Vec<u8>> {
    if mod_path.is_dir() {
        // Exact path first, then a case-insensitive scan of the folder.
        if let Ok(bytes) = std::fs::read(mod_path.join(name)) {
            return Some(bytes);
        }
        let base = name
            .rsplit(['/', '\\'])
            .next()
            .unwrap_or(name)
            .to_lowercase();
        for entry in std::fs::read_dir(mod_path).ok()? {
            let entry = entry.ok()?;
            if entry.file_name().to_string_lossy().to_lowercase() == base {
                return std::fs::read(entry.path()).ok();
            }
        }
        None
    } else if mod_path
        .extension()
        .map_or(false, |e| e.eq_ignore_ascii_case("zip"))
    {
        let file = std::fs::File::open(mod_path).ok()?;
        let mut archive = zip::ZipArchive::new(file).ok()?;
        let wanted = name.replace('\\', "/").to_lowercase();
        let base = wanted
            .rsplit('/')
            .next()
            .unwrap_or(&wanted)
            .to_string();
        let mut fallback: Option<usize> = None;
        for i in 0..archive.len() {
            let entry_name = {
                let entry = archive.by_index(i).ok()?;
                entry.name().replace('\\', "/").to_lowercase()
            };
            if entry_name == wanted {
                let mut entry = archive.by_index(i).ok()?;
                let mut buf = Vec::new();
                entry.read_to_end(&mut buf).ok()?;
                return Some(buf);
            }
            if fallback.is_none()
                && entry_name.rsplit('/').next().unwrap_or("") == base
            {
                fallback = Some(i);
            }
        }
        let i = fallback?;
        let mut entry = archive.by_index(i).ok()?;
        let mut buf = Vec::new();
        entry.read_to_end(&mut buf).ok()?;
        Some(buf)
    } else {
        None
    }
}

fn decode_dds(bytes: &[u8]) -> Option<LoadedIcon> {
    let mut cursor = Cursor::new(bytes);
    let dds = image_dds::ddsfile::Dds::read(&mut cursor).ok()?;
    let img = image_dds::image_from_dds(&dds, 0).ok()?;
    let (width, height) = (img.width(), img.height());
    Some(LoadedIcon::Rgba {
        width,
        height,
        pixels: img.into_raw(),
    })
}
